package quizfx;

public interface IQuestao {
    
    public String getRetornoAnalise();
    
    public void analisarResposta();
   
}
